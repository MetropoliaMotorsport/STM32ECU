/*
 * interrupts.h
 *
 *  Created on: 8 Jan 2019
 *      Author: drago
 */

#ifndef INTERRUPTS_H_
#define INTERRUPTS_H_

void setupInterrupts( void );

#endif /* INTERRUPTS_H_ */
