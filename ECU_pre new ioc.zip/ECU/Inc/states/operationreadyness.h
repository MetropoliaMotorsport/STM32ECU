/*
 * operationreadyness.h
 *
 *  Created on: 13 Apr 2019
 *      Author: drago
 */

#ifndef OPERATIONREADYNESS_H_
#define OPERATIONREADYNESS_H_

int OperationReadyness( uint32_t OperationLoops );

#endif /* OPERATIONREADYNESS_H_ */
