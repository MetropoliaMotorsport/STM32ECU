/*
 * operationreadyness.h
 *
 *  Created on: 13 Apr 2019
 *      Author: drago
 */

#ifndef IDLEPROCESS_H_
#define IDLEPROCESS_H_

int IdleProcess( uint32_t OperationLoops );
char OperationalReceive( uint16_t returnvalue );
char OperationalReceiveLoop( void );

#endif /* IDLEPROCESS_H_ */
