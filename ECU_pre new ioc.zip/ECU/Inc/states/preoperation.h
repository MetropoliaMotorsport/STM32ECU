/*
 * operation.h
 *
 *  Created on: 14 Mar 2019
 *      Author: drago
 */

#ifndef PREOPERATION_H_
#define PREOPERATION_H_


void setDriveMode(void);
int PreOperation( uint32_t OperationLoops );

#endif /* PREOPERATION_H_ */
