/*
 * ecumain.c
 *
 *  Created on: 14 Mar 2019
 *      Author: drago
 */

/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************

  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "dma.h"
#include "fdcan.h"
#include "i2c.h"
#include "sdmmc.h"
#include "spi.h"
#include "tim.h"
#include "usart.h"
#include "usb_otg.h"
#include "wwdg.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/

#include "ecumain.h"
#include "ecu.h"
#include "vhd44780.h"

static int OperationalState = 0;
static int NewOperationalState = 0;
static int StateTimer = 0;

HAL_StatusTypeDef SystemClock_Config(void);

static void checkButton(void);

static void checkButton(void)
{
//	uint8_t CANTxData[8];
	int curtime = gettimer();

//	The driver must be able to activate and deactivate the TS, see EV 4.10.2 and EV 4.10.3,
//	from within the cockpit without the assistance of any other person. - deactivation not handled atm?

//	Closing the shutdown circuit by any part defined in EV 6.1.2 must not (re-)activate the TS.
//	Additional action must be required.

	// deactivate

	if (curtime>(UserBtn.lastpressed+10000)){
		// 3 seconds since button last pressed, turn led on.
	//    HAL_GPIO_WritePin(LD3_GPIO_Port,LD3_Pin, 1);
	}

/*	if(UserBtn.pressed){
		UserBtn.pressed = 0;
		HAL_GPIO_TogglePin(LD3_GPIO_Port,LD3_Pin);

	//  if ( HAL_GPIO_ReadPin(USER_Btn_GPIO_Port, USER_Btn_Pin) ) // use interrupt instead
	//	  CANTxData[0] = 8;

		  while (HAL_FDCAN_GetTxFifoFreeLevel(&hfdcan1) == 0)
		  { // wait for Can to free up, need to add break after 10ms
				    if (HAL_WWDG_Refresh(&hwwdg1) != HAL_OK)
				    {
				      Error_Handler();
				    }
	      }

	} */
}

static int HardwareInit( void )
{
	ErrorState = 0;
	//  HAL_StatusTypeDef status;
	int returnval = 0;

	// run through  the cubemx generated init functions.

	/* Reset of all peripherals, Initializes the Flash interface and the Systick. */
	if ( HAL_Init() != HAL_OK )
	{
		returnval = 99; // If error in basic hardware initialisation, something very bad wrong.
	  	  	  	  	  	  //should possibly hang here, nothing yet initialised to communicate status.
	}

	/* Configure the system clock */
	if ( SystemClock_Config() != HAL_OK )
	{
		returnval = 99; // if error in setting system clock something very bad wrong.
		  	  	  	  	  //should possibly hang here, nothing yet initialised to communicate status.
	}

	/* Initialize all configured peripherals */
	MX_GPIO_Init(); // no failure return value
	// after this point can at least signal status with LED's to show error.

	MX_DMA_Init();
	MX_ADC1_Init();
	MX_FDCAN1_Init();
	MX_TIM3_Init();
	MX_FDCAN2_Init();
	MX_I2C2_Init();
	MX_TIM7_Init();

	// MX_WWDG1_Init();

	MX_TIM6_Init();
	MX_TIM17_Init();

	// after cubemx hardware inits, run our own initialisations to start up essential function.

	hd44780_Init(); // initialise LCD for debug helper information, remove for live code?

	setupCarState(); // ensures all values for state machine etc are at sanitised defaults at start.

	// should also read in defaults for calibrations, power levels etc.

	FDCAN1_start(); // sets up can ID filters and starts can bus 1
	// first point from which can messages can be sent.
	FDCAN2_start(); // starts up can bus 2

	// reset candata here somewhere?

	setupInterrupts(); // start timers etc

	startADC(); //  starts the ADC dma processing.

	//  startupLEDs(); // run little startup LED animation to indicate powered on.

	setupButtons(); // moved later, during startup sequence inputs were being triggered early

	//send can state to show hardware initialized.
	return returnval;
}


static int DevicesReady( void )
{
	static char InverterOnline = 0;
	static char PDMOnline = 0;
	static char FLeftSpeedOnline = 0;
	static char FRightSpeedOnline = 0;

	if ( CarState.SpeedSensorsDisabled ) // if we've decided to operate without speed sensors, don't wait for them
	{
		FLeftSpeedOnline = 1;
		FRightSpeedOnline = 1;
	}

	if ( CanState.InverterNMT.newdata )
	{
		CanState.InverterNMT.newdata = 0;

		// we should not have received another NMT message at this stage
		// indicates possible problem, inverter rebooted?

		if ( InverterOnline )
		{
			return 2;
		}
		if ( CanState.InverterNMT.data[0] == 0 )
		{
			InverterOnline = 1;// we have acknowledgement of activation, set online.
		}
		// check what should be being sent, seems to be just a single 0 currently?
//		5: Operational
//		 127: Pre-Operational (factory setting).
	}

	// check PDM response.

	// check datalogger response?   --

	// --
	if ( InverterOnline && PDMOnline && FLeftSpeedOnline && FRightSpeedOnline )
	{
		return 1; // return true if all devices online.
	} else
	{
		return 0;
	}
}


int CheckConfiguration( void )
{
	static int defaultconfig = 0;

	if ( !defaultconfig )
	{
		SetupADCInterpolationTables();
		defaultconfig = 1; // call interpolation table setup once only.
	}

	// set max torque request

	CarState.Torque_Req_Max = ADCState.Future_Torque_Req_Max;

	// check for config change messages.


	// if can config request testing mode, send acknowledgement, then return 10;

	return 0;
}


int ProcessData( void )
{
	processCANData();
	processADCInput();
	RearSpeedCalculation(0, 0); // feed in data.
	//FrontSpeedCalculation();
	return 0;
}

int NMTBootState( void )
{
	// send startup state message here.
	CAN_SendStatus(1, OperationalState, 0);

	// SetSensors

	if ( CAN_NMT( 0x1  ) ) // sent NMT wake up packets to can buses.
	{
	 // NMT sent, enter wait and configure state.
		return 1;

	} else
	{
	 // error sending NMT
		return 99;
	}
}

int NMTResetState( void )
{
	// send startup state message here.
	CAN_SendStatus(1, OperationalState, 0);

	if ( CAN_NMT( 0x80  ) ) // sent NMT wake up packets to can buses.
	{
	 // NMT sent, enter wait and configure state.
		return 1;

	} else
	{
	 // error sending NMT
		return 99;
	}
}


int CheckActivationRequest( void )
{
	if(UserBtn.pressed){
			UserBtn.pressed = 0;
			return 1;
	}
	else return 0;
}

int PreOperationState( void )
{
	static int PreOperationLoops = 0;
	static char RequestMode = 0;
	if ( ( PreOperationLoops % 5 ) == 0 ) // only send status message every 5'th loop.
	{
		CAN_SendStatus(1, OperationalState, 0);
	}
	PreOperationLoops++;
	// check if received configuration requests, or mode change -> testing state.

	// write any changed configuration to hard store here.

	// checks if we have heard from sensors
	// and that initial status ok before proceeding to next state.
	RequestMode = CheckConfiguration();
	switch ( DevicesReady() ) // change to bunch of if's to allow multiple failures to be reacted to?
	{
		case 0 :  // devices are ready and in pre operation state.
			// check for request to move to active state.

			if ( RequestMode ) return 10;

			if ( CheckActivationRequest() ) return 2;
			break;

		case 1 : // we are still waiting for devices.

			if ( ( CheckActivationRequest() || RequestMode ) && ( ( StateTimer + 10000*6 /*60 */ ) < gettimer() ) )
			// if been a minute and still in this state, enter error state, or go to testingmode.
			{
				if ( RequestMode ) return 10;

				// timer expired before initialisation complete, enter error state if move to next state requested.
				// this is to allow configuration / remote queries despite error status.
				// should retry NMT?
				PreOperationLoops = 0;
				return 99; // quit right away to error state.
			}

		case 2  : // inverter bad response. attempt limp mode?

		case 3 : // e.g. speed sensors sent a bad response

		default :
			// unknown/general fault status.
			PreOperationLoops = 0;
			return 99;
	}
	return OperationalState;
}


int IdleState( void )
{
	CAN_SendStatus(1, OperationalState, 0); // send when changing state instead?

	// check for error messages -> drop state.

	// at this state, everything is ready to be powered up.

	// check if TS enable pressed.

	// if so, request HV and enter next state.
	return 0;
}


int RTDMState( void )
{

	CAN_SendStatus(1, OperationalState, 0);

	//GetData();	// wait for all needed data
				//allow upto 5ms before returning with error?

	// check data validity.

	// wake up / keep alive to inverter.

	if ( RTDMCheck() ) // check if we are allowed to request power
	{

		// Call any additional processing here.

		int LeftTorque = PedalTorqueRequest();  // pedaltorquerequest = statutory requirements block in simulink.
		int RightTorque = LeftTorque;
		CANTorqueRequest( LeftTorque, RightTorque );
	}

	if ( CarState.LoggingEnabled )
	{
		CANLogData();
	}

	setLEDs();

	// check for unexpected can registration messages-> error state.

	// request sensor data / inverter status.

	// check sanity of data.

	// any errors, drop state.

	// after drop, check if limp mode possible.

	// process APPS.

	// if allowed, process torque request, else request 0.
  return 0;
}

/*
 * Primary operating function entered into after initialisation.
 */

static int OperationalProcess( void )
{
	/* states:
	 * 0 : send NMT to get inverters ready for powering on
	 * 1 : wait for nmt response, and allow configuration. Move to next state on request
	 *
	 */

	// initialise loop timer variable.
	volatile long unsigned looptimer = gettimer();

	cancount = 0;

	// if( ADCState.newdata )
	while( 1 ) // start main process loop, exit by return statement from error or request only.
	{
		if ( NewOperationalState != OperationalState ) // state has changed.
		{
			StateTimer = gettimer(); // set start of timer for how long been in new state.
			OperationalState = NewOperationalState;
		}
		if( looptimer + 10000 /* 100 */ < gettimer() ) // once per 10ms second process state
			// set to 1 second for testing log purposes.
		{
			// check how much past 10ms timer is, if too far, soft error. Allow a few times, but not too many before entering an error state?
			switch ( OperationalState )
			{
				case 0 : // NMT, initial startup.
					NewOperationalState = NMTBootState();
					break;

				case 1 : // pre operation - configuration, wait for device readyness
					NewOperationalState = PreOperationState();
					break;

				case 2 :  // run the inverter state machines to point of allowing HV
					CAN_SendStatus(1, OperationalState, 0);

					// request sensor data.

					// loop waiting for replies to sensor data, start timer.

					// if too long without data or receive an error, drop to error state.

					//  send TXStatus = 0b00000110 to move inverters to switched on.

					// check sensor sanity, enter error state if critical sensor fails sanity.

					// show error state but continue if non critical sensor fails sanity.

					// check sanity of values from sensors., check that brake / accelerator readings are within tolerance

					// check voltages, temperatures.


					// InverterStateMachine(LeftInverter, maxstate allowed);
					// InverterStateMachine(RightInverter, maxstate allowed);

					break;

				case 3 :  // idle, inverters on. Ready to enter TS
	//				NewOperationalState = IdleState();
					break;

				case 4 : // TS active, ready to enter RTDM

					CAN_SendStatus(1, OperationalState, 0);

					// check if rtdm pressed, and allow if pass rtdm check.
					break;

				case 5 : // Running in RTDM
	//				NewOperationalState = RTDMState();
					break;

				case 10 : // testing state, can only enter from state 1.

					CAN_SendStatus(1, OperationalState, 0);

					// allow config changes here?

					// implement this later.

					break;
				case 90 : // non critical error, limp potentially possible.
					CANSendPDM(0,0);
					CAN_NMT( 0x80 ); // request pre operation to restart everything.

					NewOperationalState = NMTResetState();

					// set limp mode.



				case 99 : // critical error or unknown state.

				default :

					CANSendPDM(0,0); // send high voltage off request to PDM.
					CAN_NMT( 2 ); // send stop command to all nodes.
					CAN_SendStatus(1, OperationalState, ErrorState);
					return 99; // error state, quit state machine.
			}


			// StopMotors_Switch -> ?

			looptimer = gettimer();
			//	CANKeepAlive();

	//		CANTxData[0] = gettimer()/10000;

			// testing lcd writing in main loop.
//			char buf[12];
//			sprintf(buf, "Counter %d", CANTxData[0]);
//			hd44780_writeline1(buf);

		/*	CANTxData[1] = HAL_FDCAN_GetTxFifoFreeLevel(&hfdcan1);
			//   CANTxData[2] = HAL_FDCAN_GetTxFifoFreeLevel(&hfdcan2);

			CAN1Send( &TxHeaderTime, CANTxData );
			CAN2Send( &TxHeader1, CANTxData ); */
		}
	}
//	return 1; // unneeded return after infinite while loop.
}


/**
  * @brief  The application entry point.
  * @retval int
  */
int realmain(void)
{
  /* MCU Configuration--------------------------------------------------------*/

  int MainState = 0;

 // uint8_t CANTxData[8];

  while (1) // primary state loop.
  {
	  static int InitAttempts = 0;
	  switch ( MainState )
	  {
		case 0 : // initialisation

			if ( InitAttempts < 2 ) // check number of unit attempts
			{
				switch ( HardwareInit() ) // call initialisation function.
				{
					case 0 :
						MainState = 1; // init successful, move to operational state.
						break;
					case 1 :  // init not successful in non fatal manner.
						InitAttempts++; // mark failed init, leave state at current to try again if not overrun attempts
						break;
					case 99 : // fatal init failure.

					default :
						MainState = 99;  // unrecoverable fault.
				}
			}
			else
			{
				// run out of init attempts, set error state to wait for possible reset request.
				MainState = 99;
			}

			break;

		case 1  : // operational state.
			switch ( OperationalProcess() )
			{
				case 0 : // shouldn't need to return, but enter a shutdown state or do nothing?
					break;
				case 1 : // returned with error set main error status, limp possible.
					break;
				default	: // any other state assumed to be error also.
					MainState = 99;
			}
			break;
		case 99 : //  error state
			// trigger error LED's, try to send error can bus message.
		default : // shouldn't be here, treat also as error state.
			MainState = 99;
			setOutput(1,1);
			setOutput(LED1_Output,1);
			NVIC_DisableIRQ(TIM3_IRQn); // disable blinking led to show stop error status.
			while( 1 ){}; // halt main code.
	}

  }

}

/**
  * @brief System Clock Configuration
  * @retval None
  */

HAL_StatusTypeDef SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInitStruct = {0};

  /**Supply configuration update enable
  */
  MODIFY_REG(PWR->CR3, PWR_CR3_SCUEN, 0);
  /**Configure the main internal regulator output voltage
  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  while ((PWR->D3CR & (PWR_D3CR_VOSRDY)) != PWR_D3CR_VOSRDY)
  {

  }
  /**Macro to configure the PLL clock source
  */
  __HAL_RCC_PLL_PLLSOURCE_CONFIG(RCC_PLLSOURCE_HSI);
  /**Initializes the CPU, AHB and APB busses clocks
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI48|RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_DIV1;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.HSI48State = RCC_HSI48_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 50;
  RCC_OscInitStruct.PLL.PLLP = 2;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  RCC_OscInitStruct.PLL.PLLRGE = RCC_PLL1VCIRANGE_3;
  RCC_OscInitStruct.PLL.PLLVCOSEL = RCC_PLL1VCOWIDE;
  RCC_OscInitStruct.PLL.PLLFRACN = 0;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    return 99;
  }
  /**Initializes the CPU, AHB and APB busses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2
                              |RCC_CLOCKTYPE_D3PCLK1|RCC_CLOCKTYPE_D1PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.SYSCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB3CLKDivider = RCC_APB3_DIV2;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_APB1_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_APB2_DIV2;
  RCC_ClkInitStruct.APB4CLKDivider = RCC_APB4_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
	return 99;
  }
  PeriphClkInitStruct.PeriphClockSelection = RCC_PERIPHCLK_USART2|RCC_PERIPHCLK_FDCAN
                              |RCC_PERIPHCLK_SPI5|RCC_PERIPHCLK_SPI2
                              |RCC_PERIPHCLK_SDMMC|RCC_PERIPHCLK_I2C2
                              |RCC_PERIPHCLK_ADC|RCC_PERIPHCLK_USB;
  PeriphClkInitStruct.PLL2.PLL2M = 4;
  PeriphClkInitStruct.PLL2.PLL2N = 10;
  PeriphClkInitStruct.PLL2.PLL2P = 1;
  PeriphClkInitStruct.PLL2.PLL2Q = 2;
  PeriphClkInitStruct.PLL2.PLL2R = 2;
  PeriphClkInitStruct.PLL2.PLL2RGE = RCC_PLL2VCIRANGE_3;
  PeriphClkInitStruct.PLL2.PLL2VCOSEL = RCC_PLL2VCOMEDIUM;
  PeriphClkInitStruct.PLL2.PLL2FRACN = 0;
  PeriphClkInitStruct.SdmmcClockSelection = RCC_SDMMCCLKSOURCE_PLL;
  PeriphClkInitStruct.Spi123ClockSelection = RCC_SPI123CLKSOURCE_PLL;
  PeriphClkInitStruct.Spi45ClockSelection = RCC_SPI45CLKSOURCE_D2PCLK1;
  PeriphClkInitStruct.FdcanClockSelection = RCC_FDCANCLKSOURCE_PLL2;
  PeriphClkInitStruct.Usart234578ClockSelection = RCC_USART234578CLKSOURCE_D2PCLK1;
  PeriphClkInitStruct.I2c123ClockSelection = RCC_I2C123CLKSOURCE_D2PCLK1;
  PeriphClkInitStruct.UsbClockSelection = RCC_USBCLKSOURCE_HSI48;
  PeriphClkInitStruct.AdcClockSelection = RCC_ADCCLKSOURCE_PLL2;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInitStruct) != HAL_OK)
  {
	return 99;
  }
  return 0;
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

	ErrorState = 1;

	setOutput(1,1);
	setOutput(LED1_Output,1);
	NVIC_DisableIRQ(TIM3_IRQn); // stop the timebase irq to stop blinking led and show hung for error.
	while( 1 )
	{
 //  hang code  on error.
	}
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
